from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    PROJECT_NAME: str = "Village Pond Planning System"
    API_V1_STR: str = "/api/v1"
    VERSION: str = "0.1.0"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # Maximum accepted user-selected land area (km²). Guards /analyzeLand and
    # downstream terrain processing from unreasonably large selections.
    MAX_LAND_AREA_SQ_KM: float = 100.0

    # --- DEM acquisition (Phase 2A) ---
    # Primary provider: "aws_terrain_tiles" (no API key) or "opentopography" (free API key).
    DEM_PROVIDER: str = "aws_terrain_tiles"
    # OpenTopography dataset (demtype) when that provider is used, e.g. SRTMGL1 (30 m).
    OPEN_TOPOGRAPHY_DATASET: str = "SRTMGL1"
    OPEN_TOPOGRAPHY_API_KEY: str = ""
    # Buffer added around the selected land bbox to define the hydrological analysis
    # extent (the catchment may extend beyond the selected land).
    ANALYSIS_BUFFER_METERS: float = 500.0
    # Target DEM grid resolution in meters (AWS tiles are resampled to this).
    DEM_TARGET_RESOLUTION_M: float = 30.0
    DEM_REQUEST_TIMEOUT_S: int = 45
    DEM_CACHE_DIR: str = "data/cache/dem"
    DEM_MAX_TILES: int = 64
    DEM_MAX_GRID_DIM: int = 500
    DEM_MAX_EXTENT_KM: float = 15.0
    DEM_MAX_RESPONSE_MB: int = 64

    # --- Rainfall acquisition (Phase 5) ---
    RAINFALL_YEARS_WINDOW: int = 10
    RAINFALL_REQUEST_TIMEOUT_S: int = 30
    RAINFALL_CACHE_DIR: str = "data/cache/rainfall"

    # --- Performance/scaling guards (Phase 10) ---
    MAX_UPLOAD_SIZE_MB: float = 20.0
    MAX_LAND_VERTICES: int = 2000

    # --- Distributed deployment (shared-cache / load-balanced phase) ---
    # Redis URL for the shared L2 cache (e.g. redis://172.17.0.110:6379/1).
    # Empty string disables Redis: the app then runs on local caches only and
    # every cache operation degrades gracefully (never fatal).
    REDIS_URL: str = ""
    # Identifier of this API node, included in logs/diagnostics to demonstrate
    # load balancing. Defaults to the machine hostname when empty.
    NODE_ID: str = ""
    APP_ENV: str = "production"
    # Build metadata exposed via /version (never includes secrets).
    GIT_COMMIT: str = ""
    # Cache TTLs (seconds). Elevation data is static; rainfall statistics are
    # refreshed weekly.
    DEM_CACHE_TTL_S: int = 2_592_000
    RAINFALL_CACHE_TTL_S: int = 604_800
    LOG_LEVEL: str = "INFO"

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
        extra="ignore",
    )


settings = Settings()
