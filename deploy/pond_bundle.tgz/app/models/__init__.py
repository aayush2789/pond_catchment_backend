"""Domain and database entities."""
